import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Package,
  FolderTree,
  Users,
  ReceiptText,
  Settings,
  ChevronRight,
} from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { Card } from "@/components/ui/card";
import { useDb } from "@/lib/useDb";
import { countAll, getSetting } from "@/lib/store";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Nota Toko — Beranda" },
      {
        name: "description",
        content:
          "Ringkasan toko: jumlah barang, kategori, dan pengguna. Akses cepat ke semua fitur.",
      },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: Dashboard,
});

const menu = [
  { to: "/barang", label: "Barang", desc: "Kelola produk & harga", icon: Package },
  { to: "/kategori", label: "Kategori", desc: "Kelompok barang", icon: FolderTree },
  { to: "/pengguna", label: "Pengguna", desc: "Akun kasir", icon: Users },
  { to: "/nota", label: "Nota / Cetak", desc: "Buat & cetak nota", icon: ReceiptText },
  { to: "/pengaturan", label: "Pengaturan Toko", desc: "Nama toko & info", icon: Settings },
] as const;

function Dashboard() {
  const counts = useDb(countAll);
  const namaToko = useDb(() => getSetting("nama_toko", "Toko Saya"));

  const stats = [
    { label: "Kategori", value: counts.kategori, icon: FolderTree },
    { label: "Barang", value: counts.barang, icon: Package },
    { label: "Pengguna", value: counts.pengguna, icon: Users },
  ];

  return (
    <AppShell title="Nota Toko">
      <div className="space-y-5">
        <Card className="border-none bg-gradient-to-br from-primary to-primary/80 p-5 text-primary-foreground shadow-md">
          <p className="text-sm/none opacity-80">Selamat datang di</p>
          <p className="mt-1 text-2xl font-bold">{namaToko}</p>
        </Card>

        <div className="grid grid-cols-3 gap-3">
          {stats.map((s) => {
            const Icon = s.icon;
            return (
              <Card key={s.label} className="flex flex-col items-center gap-1 p-3 text-center">
                <Icon className="h-5 w-5 text-primary" />
                <span className="text-2xl font-bold leading-none">{s.value}</span>
                <span className="text-xs text-muted-foreground">{s.label}</span>
              </Card>
            );
          })}
        </div>

        <div>
          <h2 className="mb-2 px-1 text-sm font-semibold text-muted-foreground">
            Menu
          </h2>
          <div className="space-y-2">
            {menu.map((m) => {
              const Icon = m.icon;
              return (
                <Link key={m.to} to={m.to}>
                  <Card className="flex items-center gap-3 p-3.5 transition-colors hover:bg-accent/50">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-secondary text-primary">
                      <Icon className="h-5 w-5" />
                    </span>
                    <span className="flex-1">
                      <span className="block font-semibold leading-tight">
                        {m.label}
                      </span>
                      <span className="block text-xs text-muted-foreground">
                        {m.desc}
                      </span>
                    </span>
                    <ChevronRight className="h-5 w-5 text-muted-foreground" />
                  </Card>
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </AppShell>
  );
}
