import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, Pencil, Trash2, Package } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useDb } from "@/lib/useDb";
import {
  AppDbError,
  insertBarang,
  insertKategori,
  listBarangJoined,
  listKategori,
  updateBarang,
  deleteBarang,
  type BarangJoined,
} from "@/lib/store";
import { formatRupiah } from "@/lib/format";

export const Route = createFileRoute("/barang")({
  head: () => ({
    meta: [
      { title: "Barang — Nota Toko" },
      { name: "description", content: "Kelola daftar barang, harga, dan stok toko." },
      { property: "og:url", content: "/barang" },
    ],
    links: [{ rel: "canonical", href: "/barang" }],
  }),
  component: BarangPage,
});

interface FormState {
  id: number | null;
  nama: string;
  kategori_id: string;
  harga: string;
  stok: string;
}

const emptyForm: FormState = {
  id: null,
  nama: "",
  kategori_id: "",
  harga: "",
  stok: "0",
};

function BarangPage() {
  const rows = useDb(listBarangJoined);
  const kategori = useDb(listKategori);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [toDelete, setToDelete] = useState<BarangJoined | null>(null);

  function openAdd() {
    if (kategori.length === 0) {
      toast.error("Tambah kategori dulu di menu Kategori.");
      return;
    }
    setForm({ ...emptyForm, kategori_id: String(kategori[0].id) });
    setOpen(true);
  }

  function openEdit(r: BarangJoined) {
    setForm({
      id: r.id,
      nama: r.nama,
      kategori_id: String(r.kategori_id),
      harga: String(r.harga),
      stok: String(r.stok),
    });
    setOpen(true);
  }

  function save() {
    const nama = form.nama.trim();
    if (!nama) return toast.error("Nama barang wajib diisi");
    if (!form.kategori_id) return toast.error("Pilih kategori");
    const harga = parseInt(form.harga, 10);
    if (isNaN(harga)) return toast.error("Harga harus angka");
    const stok = parseInt(form.stok, 10);
    if (isNaN(stok) || stok < 0) return toast.error("Stok tidak valid");

    const data = {
      nama,
      kategori_id: parseInt(form.kategori_id, 10),
      harga,
      stok,
    };
    try {
      if (form.id == null) {
        insertBarang(data);
        toast.success("Barang ditambahkan");
      } else {
        updateBarang(form.id, data);
        toast.success("Barang diperbarui");
      }
      setOpen(false);
    } catch (e) {
      toast.error(e instanceof AppDbError ? e.message : "Gagal menyimpan");
    }
  }

  function confirmDelete() {
    if (!toDelete) return;
    try {
      deleteBarang(toDelete.id);
      toast.success("Barang dihapus");
    } catch (e) {
      toast.error(e instanceof AppDbError ? e.message : "Gagal menghapus");
    }
    setToDelete(null);
  }

  return (
    <AppShell
      title="Barang"
      action={
        <Button size="sm" variant="secondary" onClick={openAdd}>
          <Plus className="mr-1 h-4 w-4" /> Tambah
        </Button>
      }
    >
      {rows.length === 0 ? (
        <EmptyState onAdd={openAdd} hasKategori={kategori.length > 0} />
      ) : (
        <div className="space-y-2">
          {rows.map((r) => (
            <Card key={r.id} className="flex items-center gap-3 p-3">
              <div className="min-w-0 flex-1">
                <p className="truncate font-semibold leading-tight">{r.nama}</p>
                <p className="text-xs text-muted-foreground">
                  {r.nama_kategori} · Stok {r.stok}
                </p>
                <p className="mt-0.5 text-sm font-bold text-primary">
                  {formatRupiah(r.harga)}
                </p>
              </div>
              <Button size="icon" variant="ghost" onClick={() => openEdit(r)}>
                <Pencil className="h-4 w-4" />
              </Button>
              <Button
                size="icon"
                variant="ghost"
                className="text-destructive hover:text-destructive"
                onClick={() => setToDelete(r)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{form.id == null ? "Tambah Barang" : "Edit Barang"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label>Nama Barang</Label>
              <Input
                value={form.nama}
                onChange={(e) => setForm({ ...form, nama: e.target.value })}
                placeholder="Contoh: Kopi Sachet"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Kategori</Label>
              <div className="flex gap-2">
                <Select
                  value={form.kategori_id}
                  onValueChange={(v) => setForm({ ...form, kategori_id: v })}
                >
                  <SelectTrigger className="flex-1">
                    <SelectValue placeholder="Pilih kategori" />
                  </SelectTrigger>
                  <SelectContent>
                    {kategori.map((k) => (
                      <SelectItem key={k.id} value={String(k.id)}>
                        {k.nama}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  onClick={() => {
                    const nama = window.prompt("Nama kategori baru?");
                    if (!nama?.trim()) return;
                    try {
                      insertKategori(nama.trim());
                      const next = listKategori().find(
                        (k) => k.nama === nama.trim(),
                      );
                      if (next) setForm((f) => ({ ...f, kategori_id: String(next.id) }));
                      toast.success("Kategori ditambahkan");
                    } catch (e) {
                      toast.error(e instanceof AppDbError ? e.message : "Gagal");
                    }
                  }}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Harga</Label>
                <Input
                  inputMode="numeric"
                  value={form.harga}
                  onChange={(e) => setForm({ ...form, harga: e.target.value })}
                  placeholder="0"
                />
              </div>
              <div className="space-y-1.5">
                <Label>Stok</Label>
                <Input
                  inputMode="numeric"
                  value={form.stok}
                  onChange={(e) => setForm({ ...form, stok: e.target.value })}
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>
              Batal
            </Button>
            <Button onClick={save}>Simpan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!toDelete} onOpenChange={(o) => !o && setToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus Barang</AlertDialogTitle>
            <AlertDialogDescription>
              "{toDelete?.nama}" akan dihapus permanen. Lanjutkan?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppShell>
  );
}

function EmptyState({
  onAdd,
  hasKategori,
}: {
  onAdd: () => void;
  hasKategori: boolean;
}) {
  return (
    <Card className="flex flex-col items-center gap-3 p-8 text-center">
      <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-secondary text-primary">
        <Package className="h-7 w-7" />
      </span>
      <div>
        <p className="font-semibold">Belum ada barang</p>
        <p className="text-sm text-muted-foreground">
          {hasKategori
            ? 'Klik "Tambah" untuk menambah barang.'
            : "Tambah kategori dulu di menu Kategori."}
        </p>
      </div>
      <Button onClick={onAdd}>
        <Plus className="mr-1 h-4 w-4" /> Tambah Barang
      </Button>
    </Card>
  );
}
