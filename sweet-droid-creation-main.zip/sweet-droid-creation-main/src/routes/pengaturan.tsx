import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Store, Save, Info } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useDb } from "@/lib/useDb";
import { getSetting, saveSetting } from "@/lib/store";

export const Route = createFileRoute("/pengaturan")({
  head: () => ({
    meta: [
      { title: "Pengaturan Toko — Nota Toko" },
      { name: "description", content: "Atur nama toko yang muncul di nota." },
      { property: "og:url", content: "/pengaturan" },
    ],
    links: [{ rel: "canonical", href: "/pengaturan" }],
  }),
  component: PengaturanPage,
});

function PengaturanPage() {
  const saved = useDb(() => getSetting("nama_toko", "Toko Saya"));
  const [nama, setNama] = useState(saved);

  function save() {
    const v = nama.trim();
    if (!v) return toast.error("Nama toko wajib diisi");
    saveSetting("nama_toko", v);
    toast.success("Pengaturan disimpan");
  }

  return (
    <AppShell title="Pengaturan Toko">
      <div className="space-y-4">
        <Card className="space-y-4 p-4">
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-secondary text-primary">
              <Store className="h-5 w-5" />
            </span>
            <div>
              <p className="font-semibold leading-tight">Identitas Toko</p>
              <p className="text-xs text-muted-foreground">
                Nama ini muncul di bagian atas nota.
              </p>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Nama Toko</Label>
            <Input
              value={nama}
              onChange={(e) => setNama(e.target.value)}
              placeholder="Toko Saya"
            />
          </div>
          <Button className="w-full" onClick={save}>
            <Save className="mr-1 h-4 w-4" /> Simpan
          </Button>
        </Card>

        <Card className="flex gap-3 bg-secondary/40 p-4">
          <Info className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
          <p className="text-sm text-muted-foreground">
            Semua data tersimpan di perangkat ini (offline). Tambahkan aplikasi
            ke layar utama lewat menu browser untuk membuka seperti aplikasi.
          </p>
        </Card>
      </div>
    </AppShell>
  );
}
