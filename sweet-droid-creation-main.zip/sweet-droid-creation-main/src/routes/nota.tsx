import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Plus, Minus, Printer, Trash2, ReceiptText } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useDb } from "@/lib/useDb";
import { getSetting, listBarangJoined } from "@/lib/store";
import { formatRupiah, formatDateTime } from "@/lib/format";

export const Route = createFileRoute("/nota")({
  head: () => ({
    meta: [
      { title: "Nota / Cetak — Nota Toko" },
      { name: "description", content: "Buat nota penjualan dan cetak struk." },
      { property: "og:url", content: "/nota" },
    ],
    links: [{ rel: "canonical", href: "/nota" }],
  }),
  component: NotaPage,
});

interface Line {
  barang_id: number;
  nama: string;
  harga: number;
  qty: number;
}

function NotaPage() {
  const barang = useDb(listBarangJoined);
  const namaToko = useDb(() => getSetting("nama_toko", "Toko Saya"));
  const [lines, setLines] = useState<Line[]>([]);
  const [pick, setPick] = useState("");
  const [printedAt, setPrintedAt] = useState<Date | null>(null);

  const total = useMemo(
    () => lines.reduce((s, l) => s + l.harga * l.qty, 0),
    [lines],
  );

  function addItem(id: number) {
    const b = barang.find((x) => x.id === id);
    if (!b) return;
    setLines((prev) => {
      const found = prev.find((l) => l.barang_id === id);
      if (found)
        return prev.map((l) =>
          l.barang_id === id ? { ...l, qty: l.qty + 1 } : l,
        );
      return [...prev, { barang_id: id, nama: b.nama, harga: b.harga, qty: 1 }];
    });
  }

  function changeQty(id: number, delta: number) {
    setLines((prev) =>
      prev
        .map((l) =>
          l.barang_id === id ? { ...l, qty: l.qty + delta } : l,
        )
        .filter((l) => l.qty > 0),
    );
  }

  function doPrint() {
    if (lines.length === 0) {
      toast.error("Tambah barang ke nota dulu.");
      return;
    }
    setPrintedAt(new Date());
    setTimeout(() => window.print(), 60);
  }

  return (
    <AppShell title="Nota / Cetak">
      <div className="space-y-4">
        <Card className="space-y-3 p-4">
          <p className="text-sm font-semibold text-muted-foreground">
            Pilih barang
          </p>
          {barang.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              Belum ada barang. Tambah di menu Barang.
            </p>
          ) : (
            <div className="flex gap-2">
              <Select value={pick} onValueChange={setPick}>
                <SelectTrigger className="flex-1">
                  <SelectValue placeholder="Pilih barang" />
                </SelectTrigger>
                <SelectContent>
                  {barang.map((b) => (
                    <SelectItem key={b.id} value={String(b.id)}>
                      {b.nama} — {formatRupiah(b.harga)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                onClick={() => {
                  if (!pick) return toast.error("Pilih barang dulu");
                  addItem(parseInt(pick, 10));
                }}
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          )}
        </Card>

        {lines.length === 0 ? (
          <Card className="flex flex-col items-center gap-2 p-8 text-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-secondary text-primary">
              <ReceiptText className="h-7 w-7" />
            </span>
            <p className="font-semibold">Nota kosong</p>
            <p className="text-sm text-muted-foreground">
              Pilih barang di atas untuk membuat nota.
            </p>
          </Card>
        ) : (
          <Card className="divide-y p-0">
            {lines.map((l) => (
              <div key={l.barang_id} className="flex items-center gap-3 p-3">
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium leading-tight">{l.nama}</p>
                  <p className="text-xs text-muted-foreground">
                    {formatRupiah(l.harga)} × {l.qty} ={" "}
                    {formatRupiah(l.harga * l.qty)}
                  </p>
                </div>
                <div className="flex items-center gap-1.5">
                  <Button
                    size="icon"
                    variant="outline"
                    className="h-7 w-7"
                    onClick={() => changeQty(l.barang_id, -1)}
                  >
                    <Minus className="h-3.5 w-3.5" />
                  </Button>
                  <span className="w-5 text-center text-sm font-semibold">
                    {l.qty}
                  </span>
                  <Button
                    size="icon"
                    variant="outline"
                    className="h-7 w-7"
                    onClick={() => changeQty(l.barang_id, 1)}
                  >
                    <Plus className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            ))}
          </Card>
        )}

        {lines.length > 0 && (
          <Card className="flex items-center justify-between p-4">
            <span className="text-sm font-medium text-muted-foreground">
              Total
            </span>
            <span className="text-xl font-bold text-primary">
              {formatRupiah(total)}
            </span>
          </Card>
        )}

        <div className="grid grid-cols-2 gap-3">
          <Button
            variant="outline"
            disabled={lines.length === 0}
            onClick={() => setLines([])}
          >
            <Trash2 className="mr-1 h-4 w-4" /> Kosongkan
          </Button>
          <Button disabled={lines.length === 0} onClick={doPrint}>
            <Printer className="mr-1 h-4 w-4" /> Cetak Nota
          </Button>
        </div>

        <p className="text-center text-xs text-muted-foreground">
          Cetak membuka dialog print perangkat. Pilih printer termal/Bluetooth
          yang terhubung untuk mencetak struk.
        </p>
      </div>

      {/* Off-screen printable receipt (shown only when printing) */}
      <div
        id="receipt-print"
        className="receipt-paper"
        style={{ position: "absolute", left: "-9999px", top: 0, width: "80mm" }}
      >
        <div style={{ textAlign: "center", marginBottom: "8px" }}>
          <div style={{ fontWeight: "bold", fontSize: "14px" }}>{namaToko}</div>
          <div style={{ fontSize: "11px" }}>
            {printedAt ? formatDateTime(printedAt) : ""}
          </div>
        </div>
        <div style={{ borderTop: "1px dashed #000", margin: "6px 0" }} />
        {lines.map((l) => (
          <div key={l.barang_id} style={{ fontSize: "12px", marginBottom: "4px" }}>
            <div>{l.nama}</div>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <span>
                {l.qty} x {formatRupiah(l.harga)}
              </span>
              <span>{formatRupiah(l.harga * l.qty)}</span>
            </div>
          </div>
        ))}
        <div style={{ borderTop: "1px dashed #000", margin: "6px 0" }} />
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            fontWeight: "bold",
            fontSize: "13px",
          }}
        >
          <span>TOTAL</span>
          <span>{formatRupiah(total)}</span>
        </div>
        <div
          style={{ textAlign: "center", fontSize: "11px", marginTop: "10px" }}
        >
          Terima kasih
        </div>
      </div>
    </AppShell>
  );
}
