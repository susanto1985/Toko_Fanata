import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, Pencil, Trash2, User } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useDb } from "@/lib/useDb";
import {
  AppDbError,
  deletePengguna,
  insertPengguna,
  listPengguna,
  updatePengguna,
  type Pengguna,
} from "@/lib/store";

export const Route = createFileRoute("/pengguna")({
  head: () => ({
    meta: [
      { title: "Pengguna — Nota Toko" },
      { name: "description", content: "Kelola akun pengguna / kasir toko." },
      { property: "og:url", content: "/pengguna" },
    ],
    links: [{ rel: "canonical", href: "/pengguna" }],
  }),
  component: PenggunaPage,
});

interface FormState {
  id: number | null;
  nama: string;
  username: string;
  password: string;
}

const emptyForm: FormState = { id: null, nama: "", username: "", password: "" };

function PenggunaPage() {
  const rows = useDb(listPengguna);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [toDelete, setToDelete] = useState<Pengguna | null>(null);

  function openAdd() {
    setForm(emptyForm);
    setOpen(true);
  }

  function openEdit(p: Pengguna) {
    setForm({ id: p.id, nama: p.nama, username: p.username, password: "" });
    setOpen(true);
  }

  function save() {
    const nama = form.nama.trim();
    const username = form.username.trim();
    if (!nama) return toast.error("Nama wajib diisi");
    if (!username) return toast.error("Username wajib diisi");
    if (form.id == null && !form.password)
      return toast.error("Password wajib diisi");
    try {
      if (form.id == null) {
        insertPengguna(nama, username, form.password);
        toast.success("Pengguna ditambahkan");
      } else {
        updatePengguna(form.id, nama, username, form.password || undefined);
        toast.success("Pengguna diperbarui");
      }
      setOpen(false);
    } catch (e) {
      toast.error(e instanceof AppDbError ? e.message : "Gagal menyimpan");
    }
  }

  function confirmDelete() {
    if (!toDelete) return;
    deletePengguna(toDelete.id);
    toast.success("Pengguna dihapus");
    setToDelete(null);
  }

  return (
    <AppShell
      title="Pengguna"
      action={
        <Button size="sm" variant="secondary" onClick={openAdd}>
          <Plus className="mr-1 h-4 w-4" /> Tambah
        </Button>
      }
    >
      {rows.length === 0 ? (
        <Card className="flex flex-col items-center gap-3 p-8 text-center">
          <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-secondary text-primary">
            <User className="h-7 w-7" />
          </span>
          <p className="font-semibold">Belum ada pengguna</p>
          <Button onClick={openAdd}>
            <Plus className="mr-1 h-4 w-4" /> Tambah Pengguna
          </Button>
        </Card>
      ) : (
        <div className="space-y-2">
          {rows.map((p) => (
            <Card key={p.id} className="flex items-center gap-3 p-3.5">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-secondary text-primary">
                <User className="h-5 w-5" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate font-semibold leading-tight">{p.nama}</p>
                <p className="text-xs text-muted-foreground">@{p.username}</p>
              </div>
              <Button size="icon" variant="ghost" onClick={() => openEdit(p)}>
                <Pencil className="h-4 w-4" />
              </Button>
              <Button
                size="icon"
                variant="ghost"
                className="text-destructive hover:text-destructive"
                onClick={() => setToDelete(p)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {form.id == null ? "Tambah Pengguna" : "Edit Pengguna"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label>Nama</Label>
              <Input
                value={form.nama}
                onChange={(e) => setForm({ ...form, nama: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Username</Label>
              <Input
                value={form.username}
                onChange={(e) => setForm({ ...form, username: e.target.value })}
                autoCapitalize="none"
              />
            </div>
            <div className="space-y-1.5">
              <Label>
                Password{" "}
                {form.id != null && (
                  <span className="text-xs font-normal text-muted-foreground">
                    (kosongkan jika tidak diubah)
                  </span>
                )}
              </Label>
              <Input
                type="password"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>
              Batal
            </Button>
            <Button onClick={save}>Simpan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!toDelete} onOpenChange={(o) => !o && setToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus Pengguna</AlertDialogTitle>
            <AlertDialogDescription>
              "{toDelete?.nama}" akan dihapus. Lanjutkan?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppShell>
  );
}
