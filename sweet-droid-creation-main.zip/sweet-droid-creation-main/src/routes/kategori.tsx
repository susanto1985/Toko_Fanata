import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, Trash2, FolderTree } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useDb } from "@/lib/useDb";
import {
  AppDbError,
  deleteKategori,
  insertKategori,
  listKategoriWithCount,
  type Kategori,
} from "@/lib/store";

export const Route = createFileRoute("/kategori")({
  head: () => ({
    meta: [
      { title: "Kategori — Nota Toko" },
      { name: "description", content: "Kelola kategori untuk mengelompokkan barang toko." },
      { property: "og:url", content: "/kategori" },
    ],
    links: [{ rel: "canonical", href: "/kategori" }],
  }),
  component: KategoriPage,
});

function KategoriPage() {
  const rows = useDb(listKategoriWithCount);
  const [open, setOpen] = useState(false);
  const [nama, setNama] = useState("");
  const [toDelete, setToDelete] = useState<Kategori | null>(null);

  function save() {
    const v = nama.trim();
    if (!v) return toast.error("Nama kategori wajib diisi");
    try {
      insertKategori(v);
      toast.success("Kategori ditambahkan");
      setNama("");
      setOpen(false);
    } catch (e) {
      toast.error(e instanceof AppDbError ? e.message : "Gagal menyimpan");
    }
  }

  function confirmDelete() {
    if (!toDelete) return;
    try {
      deleteKategori(toDelete.id);
      toast.success("Kategori dihapus");
    } catch (e) {
      toast.error(e instanceof AppDbError ? e.message : "Gagal menghapus");
    }
    setToDelete(null);
  }

  return (
    <AppShell
      title="Kategori"
      action={
        <Button size="sm" variant="secondary" onClick={() => setOpen(true)}>
          <Plus className="mr-1 h-4 w-4" /> Tambah
        </Button>
      }
    >
      {rows.length === 0 ? (
        <Card className="flex flex-col items-center gap-3 p-8 text-center">
          <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-secondary text-primary">
            <FolderTree className="h-7 w-7" />
          </span>
          <p className="font-semibold">Belum ada kategori</p>
          <Button onClick={() => setOpen(true)}>
            <Plus className="mr-1 h-4 w-4" /> Tambah Kategori
          </Button>
        </Card>
      ) : (
        <div className="space-y-2">
          {rows.map((k) => (
            <Card key={k.id} className="flex items-center gap-3 p-3.5">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-secondary text-primary">
                <FolderTree className="h-5 w-5" />
              </span>
              <div className="flex-1">
                <p className="font-semibold leading-tight">{k.nama}</p>
                <p className="text-xs text-muted-foreground">
                  {k.item_count} barang
                </p>
              </div>
              <Button
                size="icon"
                variant="ghost"
                className="text-destructive hover:text-destructive"
                onClick={() => setToDelete(k)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Tambah Kategori</DialogTitle>
          </DialogHeader>
          <div className="space-y-1.5">
            <Label>Nama Kategori</Label>
            <Input
              value={nama}
              onChange={(e) => setNama(e.target.value)}
              placeholder="Contoh: Minuman"
              onKeyDown={(e) => e.key === "Enter" && save()}
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>
              Batal
            </Button>
            <Button onClick={save}>Simpan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!toDelete} onOpenChange={(o) => !o && setToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus Kategori</AlertDialogTitle>
            <AlertDialogDescription>
              "{toDelete?.nama}" akan dihapus. Lanjutkan?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppShell>
  );
}
