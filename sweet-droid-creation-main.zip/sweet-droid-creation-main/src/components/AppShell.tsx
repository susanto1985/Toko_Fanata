import { Link, useRouterState } from "@tanstack/react-router";
import { Home, Package, ReceiptText, Settings } from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

const navItems = [
  { to: "/", label: "Beranda", icon: Home },
  { to: "/barang", label: "Barang", icon: Package },
  { to: "/nota", label: "Nota", icon: ReceiptText },
  { to: "/pengaturan", label: "Pengaturan", icon: Settings },
] as const;

export function AppShell({
  title,
  children,
  action,
}: {
  title: string;
  children: ReactNode;
  action?: ReactNode;
}) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-20 border-b bg-primary text-primary-foreground shadow-sm">
        <div
          className="mx-auto flex max-w-md items-center justify-between gap-3 px-4 py-3"
          style={{ paddingTop: "max(0.75rem, env(safe-area-inset-top))" }}
        >
          <h1 className="text-lg font-bold tracking-tight">{title}</h1>
          {action}
        </div>
      </header>

      <main className="mx-auto w-full max-w-md px-4 pb-28 pt-4">{children}</main>

      <nav
        className="fixed inset-x-0 bottom-0 z-20 border-t bg-card"
        style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
      >
        <div className="mx-auto grid max-w-md grid-cols-4">
          {navItems.map((item) => {
            const active =
              item.to === "/"
                ? pathname === "/"
                : pathname.startsWith(item.to);
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex flex-col items-center gap-1 py-2.5 text-xs font-medium transition-colors",
                  active
                    ? "text-primary"
                    : "text-muted-foreground hover:text-foreground",
                )}
              >
                <Icon className="h-5 w-5" />
                {item.label}
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
