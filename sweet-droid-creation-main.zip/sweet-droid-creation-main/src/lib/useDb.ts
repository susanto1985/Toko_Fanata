import { useMemo, useSyncExternalStore } from "react";
import { subscribe, getVersion } from "./store";

// Subscribes to store changes via a stable version counter, then computes the
// selector result with useMemo so the value is referentially stable between
// renders. This avoids the infinite update loop that occurs when a selector
// returns a fresh object/array on every call.
export function useDb<T>(selector: () => T): T {
  const version = useSyncExternalStore(subscribe, getVersion, getVersion);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  return useMemo(() => selector(), [version, selector]);
}
