export function formatRupiah(value: unknown): string {
  let n = 0;
  if (typeof value === "number") n = Math.trunc(value);
  else if (value != null) n = parseInt(String(value), 10) || 0;
  const formatted = n
    .toString()
    .replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  return `Rp${formatted}`;
}

export function formatDateTime(d: Date): string {
  const pad = (x: number) => x.toString().padStart(2, "0");
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(
    d.getHours(),
  )}:${pad(d.getMinutes())}`;
}
