// Offline-first data layer backed by localStorage.
// Mirrors the original Flutter SQLite schema for Nota Toko.

export interface Kategori {
  id: number;
  nama: string;
}

export interface Barang {
  id: number;
  nama: string;
  kategori_id: number;
  harga: number;
  stok: number;
}

export interface Pengguna {
  id: number;
  nama: string;
  username: string;
  password_b64: string;
}

export interface NotaItem {
  barang_id: number;
  nama: string;
  harga: number;
  qty: number;
}

interface DbShape {
  kategori: Kategori[];
  barang: Barang[];
  pengguna: Pengguna[];
  pengaturan: Record<string, string>;
  seq: { kategori: number; barang: number; pengguna: number };
}

const KEY = "nota_toko_db_v1";

const empty: DbShape = {
  kategori: [],
  barang: [],
  pengguna: [],
  pengaturan: {},
  seq: { kategori: 0, barang: 0, pengguna: 0 },
};

function read(): DbShape {
  if (typeof window === "undefined") return structuredClone(empty);
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return structuredClone(empty);
    const parsed = JSON.parse(raw) as Partial<DbShape>;
    return {
      ...structuredClone(empty),
      ...parsed,
      seq: { ...empty.seq, ...(parsed.seq ?? {}) },
      pengaturan: { ...empty.pengaturan, ...(parsed.pengaturan ?? {}) },
    };
  } catch {
    return structuredClone(empty);
  }
}

const listeners = new Set<() => void>();

// Cached snapshot: a stable reference that only changes on write.
// Required for useSyncExternalStore to avoid infinite update loops.
let cached: DbShape | null = null;
let version = 0;

function getCached(): DbShape {
  if (cached === null) cached = read();
  return cached;
}

function write(db: DbShape) {
  if (typeof window !== "undefined") {
    window.localStorage.setItem(KEY, JSON.stringify(db));
  }
  cached = db;
  version += 1;
  listeners.forEach((l) => l());
}

export function subscribe(cb: () => void) {
  listeners.add(cb);
  return () => listeners.delete(cb);
}

// Stable version counter for useSyncExternalStore.
export function getVersion(): number {
  return version;
}

export function snapshot(): DbShape {
  return getCached();
}

export class AppDbError extends Error {}

// ---- Kategori ----
export function listKategori(): Kategori[] {
  return [...read().kategori].sort((a, b) => a.nama.localeCompare(b.nama));
}

export function listKategoriWithCount(): (Kategori & { item_count: number })[] {
  const db = read();
  return [...db.kategori]
    .sort((a, b) => a.nama.localeCompare(b.nama))
    .map((k) => ({
      ...k,
      item_count: db.barang.filter((b) => b.kategori_id === k.id).length,
    }));
}

export function insertKategori(nama: string) {
  const db = read();
  if (db.kategori.some((k) => k.nama.toLowerCase() === nama.toLowerCase())) {
    throw new AppDbError("Kategori sudah ada atau tidak valid");
  }
  db.seq.kategori += 1;
  db.kategori.push({ id: db.seq.kategori, nama });
  write(db);
}

export function deleteKategori(id: number) {
  const db = read();
  if (db.barang.some((b) => b.kategori_id === id)) {
    throw new AppDbError("Gagal: Kategori masih digunakan oleh barang");
  }
  db.kategori = db.kategori.filter((k) => k.id !== id);
  write(db);
}

// ---- Barang ----
export interface BarangJoined extends Barang {
  nama_barang: string;
  nama_kategori: string;
}

export function listBarangJoined(): BarangJoined[] {
  const db = read();
  return [...db.barang]
    .sort((a, b) => b.id - a.id)
    .map((b) => ({
      ...b,
      nama_barang: b.nama,
      nama_kategori:
        db.kategori.find((k) => k.id === b.kategori_id)?.nama ?? "-",
    }));
}

export function getBarang(id: number): Barang {
  const b = read().barang.find((x) => x.id === id);
  if (!b) throw new AppDbError("Barang tidak ditemukan");
  return b;
}

export function insertBarang(data: Omit<Barang, "id">) {
  const db = read();
  db.seq.barang += 1;
  db.barang.push({ id: db.seq.barang, ...data });
  write(db);
}

export function updateBarang(id: number, data: Omit<Barang, "id">) {
  const db = read();
  const i = db.barang.findIndex((b) => b.id === id);
  if (i === -1) throw new AppDbError("Barang tidak ditemukan");
  db.barang[i] = { id, ...data };
  write(db);
}

export function deleteBarang(id: number) {
  const db = read();
  db.barang = db.barang.filter((b) => b.id !== id);
  write(db);
}

// ---- Pengguna ----
export function listPengguna(): Pengguna[] {
  return [...read().pengguna].sort((a, b) => b.id - a.id);
}

export function getPengguna(id: number): Pengguna {
  const p = read().pengguna.find((x) => x.id === id);
  if (!p) throw new AppDbError("Pengguna tidak ditemukan");
  return p;
}

function b64(raw: string) {
  return typeof btoa !== "undefined" ? btoa(unescape(encodeURIComponent(raw))) : raw;
}

export function insertPengguna(nama: string, username: string, passwordRaw: string) {
  const db = read();
  if (db.pengguna.some((p) => p.username.toLowerCase() === username.toLowerCase())) {
    throw new AppDbError("Username sudah dipakai");
  }
  db.seq.pengguna += 1;
  db.pengguna.push({
    id: db.seq.pengguna,
    nama,
    username,
    password_b64: b64(passwordRaw),
  });
  write(db);
}

export function updatePengguna(
  id: number,
  nama: string,
  username: string,
  passwordRaw?: string,
) {
  const db = read();
  const i = db.pengguna.findIndex((p) => p.id === id);
  if (i === -1) throw new AppDbError("Pengguna tidak ditemukan");
  if (
    db.pengguna.some(
      (p) => p.id !== id && p.username.toLowerCase() === username.toLowerCase(),
    )
  ) {
    throw new AppDbError("Username sudah dipakai");
  }
  db.pengguna[i] = {
    id,
    nama,
    username,
    password_b64: passwordRaw ? b64(passwordRaw) : db.pengguna[i].password_b64,
  };
  write(db);
}

export function deletePengguna(id: number) {
  const db = read();
  db.pengguna = db.pengguna.filter((p) => p.id !== id);
  write(db);
}

// ---- Pengaturan ----
export function getSetting(key: string, def: string): string {
  return read().pengaturan[key] ?? def;
}

export function saveSetting(key: string, value: string) {
  const db = read();
  db.pengaturan[key] = value;
  write(db);
}

// ---- Counts ----
export function countAll() {
  const db = read();
  return {
    kategori: db.kategori.length,
    barang: db.barang.length,
    pengguna: db.pengguna.length,
  };
}
